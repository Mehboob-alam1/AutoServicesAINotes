package com.example.auto_services_ai_notes

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
