import 'dart:ui';

const kBGDarkColor = Color(0xFF001A4D);

const kWhiteColor = Color(0xFFFFFFFF);
const kBlackColor = Color(0xFF000000);